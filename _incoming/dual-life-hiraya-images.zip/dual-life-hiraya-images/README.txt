dual-life-hiraya 画像セット

用途: /iezukuri/plan/dual-life-hiraya 用
テーマ: 二拠点生活向け平屋 / ローコスト住宅 / 72㎡以下
想定面積: 延床 約68.5㎡（約20.7坪） / デッキ 約8.0㎡（約2.4坪）

ファイル:
01 exterior_work_21tsubo
- 施工実例 Works 用: 外観写真

02 ldk_16-9jo
- 施工実例 Works 用: LDK
- LDK 約28.0㎡（約16.9帖）想定

03 flex-guest-room_5-4jo
- 施工実例 Works 用: フレックスルーム / ゲストルーム
- 約9.0㎡（約5.4帖）想定

04 bath-washroom-laundry
- 施工実例 Works 用: 浴室・洗面・ランドリー
- 浴室 約3.0㎡ / 洗面ランドリー 約3.0㎡ / トイレ 約1.5㎡想定

05 floor-plan_68-5sqm_20-7tsubo
- 間取りとプラン Plans 用: 平面図
- 延床 約68.5㎡（約20.7坪）想定

06 site-plan_parking-deck-garden
- 間取りとプラン Plans 用: 配置図
- 駐車場、デッキ、庭、アプローチ想定
